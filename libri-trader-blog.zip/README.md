# LIBRI TRADER - Fashion & Lifestyle Blog

A modern, sophisticated fashion and lifestyle blog website inspired by The Blonde Salad, designed with premium aesthetics and responsive functionality.

## ✨ Features

- **Modern Design**: Clean, elegant layout with sophisticated typography
- **Responsive**: Fully responsive design that works on all devices
- **Performance Optimized**: Fast loading with optimized images and animations
- **Interactive Elements**: Smooth scrolling, hover effects, and animations
- **Newsletter Signup**: Built-in newsletter subscription functionality
- **Category Filtering**: Interactive article filtering by categories
- **Mobile-First**: Hamburger menu and mobile-optimized navigation

## 🎨 Design Elements

- **Typography**: Playfair Display (headlines) + Work Sans (body)
- **Color Scheme**: Elegant gold accent (#B2967D) with warm neutral tones
- **Layout**: Magazine-style grid with featured content
- **Components**: Article cards, category sections, hero banner, newsletter

## 📱 Sections

1. **Navigation Header** - Fixed header with navigation menu
2. **Hero Section** - Featured article with call-to-action
3. **Latest Articles** - Grid of recent articles with categories
4. **Categories** - Interactive category cards (Fashion, Beauty, Lifestyle)
5. **Newsletter** - Email subscription form
6. **Footer** - Links and social media

## 🛠️ Technologies Used

- HTML5
- CSS3 (with custom properties and grid/flexbox)
- Vanilla JavaScript
- Google Fonts (Playfair Display, Work Sans)
- Unsplash Images (for placeholders)

## 🚀 Deployment

To deploy this website:

### Option 1: GitHub Pages (Free)
1. Create a new GitHub repository
2. Upload all files to the repository
3. Go to Settings > Pages
4. Select "Deploy from a branch" and choose "main" branch
5. Your site will be available at `https://username.github.io/repository-name`

### Option 2: Netlify (Free)
1. Create an account at netlify.com
2. Drag and drop the folder with the HTML/CSS/JS files
3. Your site will be live instantly with a custom URL

### Option 3: Vercel (Free)
1. Create an account at vercel.com
2. Import your GitHub repository
3. Deploy with one click

## 📁 File Structure

```
├── index.html          # Main HTML file
├── styles.css          # All CSS styles
├── script.js           # JavaScript functionality
└── README.md           # This file
```

## 🎯 Customization

### Colors
The website uses CSS custom properties for easy color customization:

```css
:root {
    --gold-500: #B2967D;      /* Primary accent color */
    --text-primary: #1C1C1C;   /* Main text color */
    --surface-bg: #FFFFFF;     /* Card background */
    --page-bg: #FDFCFB;        /* Page background */
}
```

### Content
- Update the hero section in `index.html`
- Modify article cards in the articles grid
- Change category sections and descriptions
- Update footer links and social media

### Images
Replace the Unsplash placeholder images with your own:
- Hero image: ~1000x600px
- Article images: ~600x400px
- Category images: ~800x600px

## 📊 Performance Features

- Optimized images with proper sizing
- CSS animations with hardware acceleration
- Debounced scroll events
- Lazy loading considerations
- Mobile-first responsive design

## 🌟 Credits

- Design inspired by The Blonde Salad
- Images from Unsplash
- Typography from Google Fonts
- Built with modern web standards

---

**Author**: MiniMax Agent  
**Created**: 2025  
**License**: MIT

For questions or support, please contact libritrader@gmail.com