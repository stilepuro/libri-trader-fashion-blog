// ===== MOBILE NAVIGATION =====
document.addEventListener('DOMContentLoaded', function() {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');
    
    // Toggle mobile menu
    hamburger.addEventListener('click', function() {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });
    
    // Close mobile menu when clicking on a link
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });
    
    // ===== SMOOTH SCROLLING =====
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            
            if (targetId.startsWith('#')) {
                const targetSection = document.querySelector(targetId);
                if (targetSection) {
                    const headerHeight = document.querySelector('.header').offsetHeight;
                    const targetPosition = targetSection.offsetTop - headerHeight - 20;
                    
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
    
    // ===== ARTICLE CARD INTERACTIONS =====
    const articleCards = document.querySelectorAll('.article-card');
    
    articleCards.forEach(card => {
        // Add click functionality to read more links
        const readMoreLink = card.querySelector('.read-more');
        const categoryTag = card.querySelector('.category');
        
        if (readMoreLink) {
            readMoreLink.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Get article title for demonstration
                const articleTitle = card.querySelector('h3').textContent;
                const articleCategory = categoryTag.textContent;
                
                // Simple alert for demonstration - in a real site, this would navigate to the article
                showArticlePreview(articleTitle, articleCategory);
            });
        }
        
        // Add hover effect for category tags
        if (categoryTag) {
            categoryTag.addEventListener('click', function() {
                filterByCategory(this.textContent);
            });
        }
    });
    
    // ===== CATEGORY CARD INTERACTIONS =====
    const categoryCards = document.querySelectorAll('.category-card');
    
    categoryCards.forEach(card => {
        card.addEventListener('click', function() {
            const categoryId = this.id;
            const categoryName = this.querySelector('h3').textContent;
            
            // Scroll to articles section and filter
            const articlesSection = document.querySelector('.articles-grid');
            if (articlesSection) {
                articlesSection.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
                
                // Filter articles by category after a delay
                setTimeout(() => {
                    filterByCategory(categoryName);
                }, 800);
            }
        });
    });
    
    // ===== NEWSLETTER FORM =====
    const newsletterForm = document.querySelector('.newsletter-form');
    
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const emailInput = this.querySelector('input[type="email"]');
            const email = emailInput.value.trim();
            
            if (email) {
                // Simulate subscription success
                showSubscriptionSuccess(email);
                emailInput.value = '';
            }
        });
    });
    
    // ===== HERO CTA BUTTON =====
    const ctaButton = document.querySelector('.cta-button');
    
    if (ctaButton) {
        ctaButton.addEventListener('click', function() {
            // Scroll to latest articles
            const latestArticles = document.querySelector('.section .articles-grid');
            if (latestArticles) {
                latestArticles.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    }
    
    // ===== SCROLL ANIMATIONS =====
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe article cards for animation
    articleCards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });
    
    // ===== HEADER SCROLL EFFECT =====
    let lastScrollTop = 0;
    const header = document.querySelector('.header');
    
    window.addEventListener('scroll', function() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        // Add/remove shadow based on scroll position
        if (scrollTop > 10) {
            header.style.boxShadow = '0 2px 20px rgba(0,0,0,0.1)';
        } else {
            header.style.boxShadow = 'none';
        }
        
        lastScrollTop = scrollTop;
    });
});

// ===== UTILITY FUNCTIONS =====

function showArticlePreview(title, category) {
    // Create modal overlay
    const modal = document.createElement('div');
    modal.className = 'article-modal';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
        opacity: 0;
        transition: opacity 0.3s ease;
    `;
    
    // Create modal content
    const modalContent = document.createElement('div');
    modalContent.style.cssText = `
        background: white;
        padding: 40px;
        border-radius: 8px;
        max-width: 500px;
        text-align: center;
        transform: scale(0.8);
        transition: transform 0.3s ease;
    `;
    
    modalContent.innerHTML = `
        <h3 style="margin-bottom: 16px; color: #1C1C1C; font-family: 'Playfair Display', serif;">${title}</h3>
        <p style="margin-bottom: 24px; color: #6B6B6B; font-size: 14px; font-weight: 600; letter-spacing: 1px; text-transform: uppercase;">${category}</p>
        <p style="margin-bottom: 32px; color: #6B6B6B;">This is a demonstration of the article preview. In a real website, this would navigate to the full article page.</p>
        <button onclick="closeModal()" style="padding: 12px 32px; background: #B2967D; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Close</button>
    `;
    
    modal.appendChild(modalContent);
    document.body.appendChild(modal);
    
    // Animate in
    setTimeout(() => {
        modal.style.opacity = '1';
        modalContent.style.transform = 'scale(1)';
    }, 10);
    
    // Close on overlay click
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            closeModal();
        }
    });
    
    // Store modal reference globally
    window.currentModal = modal;
}

function closeModal() {
    const modal = window.currentModal;
    if (modal) {
        modal.style.opacity = '0';
        modal.querySelector('div').style.transform = 'scale(0.8)';
        
        setTimeout(() => {
            document.body.removeChild(modal);
            window.currentModal = null;
        }, 300);
    }
}

function filterByCategory(category) {
    const articleCards = document.querySelectorAll('.article-card');
    
    articleCards.forEach((card, index) => {
        const cardCategory = card.querySelector('.category').textContent;
        
        setTimeout(() => {
            if (cardCategory === category) {
                card.style.display = 'block';
                card.style.opacity = '0';
                card.style.transform = 'translateY(30px)';
                
                // Animate in
                setTimeout(() => {
                    card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, 50);
            } else {
                card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                card.style.opacity = '0.3';
                card.style.transform = 'scale(0.95)';
            }
        }, index * 100);
    });
    
    // Show reset message
    setTimeout(() => {
        const resetButton = document.createElement('button');
        resetButton.textContent = 'Show All Articles';
        resetButton.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            padding: 12px 24px;
            background: #B2967D;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            z-index: 1000;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            transition: all 0.3s ease;
        `;
        
        resetButton.addEventListener('click', function() {
            resetArticles();
            document.body.removeChild(resetButton);
        });
        
        resetButton.addEventListener('mouseover', function() {
            this.style.transform = 'translateY(-2px)';
            this.style.boxShadow = '0 6px 20px rgba(0,0,0,0.2)';
        });
        
        resetButton.addEventListener('mouseout', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
        });
        
        document.body.appendChild(resetButton);
        
        // Auto remove after 10 seconds
        setTimeout(() => {
            if (document.body.contains(resetButton)) {
                document.body.removeChild(resetButton);
            }
        }, 10000);
    }, articleCards.length * 100 + 500);
}

function resetArticles() {
    const articleCards = document.querySelectorAll('.article-card');
    
    articleCards.forEach((card, index) => {
        setTimeout(() => {
            card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            card.style.opacity = '1';
            card.style.transform = 'scale(1)';
        }, index * 50);
    });
}

function showSubscriptionSuccess(email) {
    // Create success message
    const successMessage = document.createElement('div');
    successMessage.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: #287D3C;
        color: white;
        padding: 20px;
        border-radius: 4px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 1000;
        opacity: 0;
        transform: translateX(100%);
        transition: all 0.3s ease;
        max-width: 300px;
    `;
    
    successMessage.innerHTML = `
        <h4 style="margin-bottom: 8px; font-size: 16px;">Thank You!</h4>
        <p style="font-size: 14px; margin: 0;">You've been subscribed to our newsletter at ${email}</p>
    `;
    
    document.body.appendChild(successMessage);
    
    // Animate in
    setTimeout(() => {
        successMessage.style.opacity = '1';
        successMessage.style.transform = 'translateX(0)';
    }, 10);
    
    // Animate out after 5 seconds
    setTimeout(() => {
        successMessage.style.opacity = '0';
        successMessage.style.transform = 'translateX(100%)';
        
        setTimeout(() => {
            if (document.body.contains(successMessage)) {
                document.body.removeChild(successMessage);
            }
        }, 300);
    }, 5000);
}

// ===== MOBILE MENU STYLES =====
const mobileMenuStyles = `
@media (max-width: 768px) {
    .nav-menu {
        position: fixed;
        left: -100%;
        top: 80px;
        flex-direction: column;
        background-color: white;
        width: 100%;
        text-align: center;
        transition: 0.3s;
        box-shadow: 0 10px 27px rgba(0,0,0,0.05);
        padding: 40px 0;
    }
    
    .nav-menu.active {
        left: 0;
    }
    
    .nav-menu li {
        margin: 20px 0;
    }
    
    .hamburger.active .bar:nth-child(2) {
        opacity: 0;
    }
    
    .hamburger.active .bar:nth-child(1) {
        transform: translateY(9px) rotate(45deg);
    }
    
    .hamburger.active .bar:nth-child(3) {
        transform: translateY(-9px) rotate(-45deg);
    }
}
`;

// Add mobile menu styles to head
const style = document.createElement('style');
style.textContent = mobileMenuStyles;
document.head.appendChild(style);

// ===== KEYBOARD NAVIGATION =====
document.addEventListener('keydown', function(e) {
    // Close modal with Escape key
    if (e.key === 'Escape' && window.currentModal) {
        closeModal();
    }
    
    // Navigate with arrow keys (future enhancement)
    if (e.key === 'ArrowDown') {
        // Could implement article navigation
    }
});

// ===== PERFORMANCE OPTIMIZATIONS =====
// Debounce scroll events
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Apply debounce to scroll event
const debouncedScrollHandler = debounce(function() {
    // Additional scroll-based animations could go here
}, 100);

window.addEventListener('scroll', debouncedScrollHandler);

// ===== ACCESSIBILITY ENHANCEMENTS =====
document.addEventListener('DOMContentLoaded', function() {
    // Add focus indicators for keyboard navigation
    const focusableElements = document.querySelectorAll('a, button, input, [tabindex]:not([tabindex="-1"])');
    
    focusableElements.forEach(element => {
        element.addEventListener('focus', function() {
            this.style.outline = '2px solid #B2967D';
            this.style.outlineOffset = '2px';
        });
        
        element.addEventListener('blur', function() {
            this.style.outline = 'none';
        });
    });
    
    // Add aria labels for better screen reader support
    const hamburgerButton = document.querySelector('.hamburger');
    if (hamburgerButton) {
        hamburgerButton.setAttribute('aria-label', 'Toggle mobile menu');
    }
    
    const newsletterInput = document.querySelector('.newsletter-form input');
    if (newsletterInput) {
        newsletterInput.setAttribute('aria-label', 'Email address for newsletter subscription');
    }
});